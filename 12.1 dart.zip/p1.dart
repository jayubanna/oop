class Book {
  late String _title;
  late String _author;
  late double _price;

  Book({required String title, required String author, required double price}) {
    _title = title;
    _author = author;
    _price = price;
  }

  String get title => _title;
  String get author => _author;
  double get price => _price;

  set title(String value) => _title = value;
  set author(String value) => _author = value;
  set price(double value) => _price = value;
}

void main() {
  Book book =
      Book(title: 'To Kill a Mockingbird', author: 'Harper Lee', price: 19.99);

  print(book.title);
  print(book.author);
  print(book.price);
}
