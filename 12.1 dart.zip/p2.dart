class BankAccount {
  final int _accountNumber;
  double _balance;

  BankAccount({required int accountNumber, double balance = 0.0})
      : _accountNumber = accountNumber,
        _balance = balance;

  int get accountNumber => _accountNumber;

  double get balance => _balance;
  set balance(double value) => _balance = value;

  void deposit(double amount) {
    if (amount > 0) {
      _balance += amount;
    } else {
      print("Deposit...");
    }
  }

  void withdraw(double amount) {
    if (amount > 0 && amount <= _balance) {
      _balance -= amount;
    } else {
      print("Withdrawal...");
    }
  }
}

void main() {
  BankAccount account =
      BankAccount(accountNumber: 122956546472, balance: 1000.0);

  print("accountNumber:-${account.accountNumber}");
  print("balance:-${account.balance}");

  account.deposit(1500.0);
  print("deposit after balance:-${account.balance}");

  account.withdraw(500.0);
  print("withdraw after balance:-${account.balance}");
}
