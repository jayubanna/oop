class Employee {
  int id;
  String name;
  double salary;

  Employee(this.id, this.name, this.salary);

  void display() {
    print('ID: $id, Name: $name, Salary: $salary');
  }
}

void main() {
  Employee employee1 = Employee(1, 'krish', 50000.0);
  Employee employee2 = Employee(2, 'karan', 60000.0);
  Employee employee3 = Employee(3, 'harsh ', 70000.0);

  employee1.display();
  employee2.display();
  employee3.display();
}