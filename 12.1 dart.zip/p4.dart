class Counter {
  static int count = 1;

  void increment() {
    Counter.count++;
  }

  int getCount() {
    return Counter.count;
  }
}

void main() {
  Counter counter1 = Counter();
  Counter counter2 = Counter();
  Counter counter3 = Counter();
  Counter counter4 = Counter();

  counter1.increment();
  // print('Counter 1: ${counter1.getCount()}');

  counter2.increment();
  // print('Counter 2: ${counter2.getCount()}');

  counter3.increment();
  // print('Counter 3: ${counter3.getCount()}');

  counter4.increment();
  // print('Counter 4: ${counter4.getCount()}');

  print('Counter 1: ${counter1.getCount()}');
  print('Counter 2: ${counter2.getCount()}');
  print('Counter 3: ${counter3.getCount()}');
  print('Counter 4: ${counter4.getCount()}');
}
