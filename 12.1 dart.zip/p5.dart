class Car {
  String _brand;
  String _model;
  int _year;

  Car(this._brand, this._model, this._year);

  String get brand => _brand;
  String get model => _model;
  int get year => _year;

  set brand(String value) {
    if (value.isNotEmpty) {
      _brand = value;
    } else {
      print('Brand cannot be empty');
    }
  }

  set model(String value) {
    if (value.isNotEmpty) {
      _model = value;
    } else {
      print('Model cannot be empty');
    }
  }

  set year(int value) {
    if (value > 0) {
      _year = value;
    } else {
      print('Year must be a positive integer');
    }
  }
}

void main() {
  Car myCar = Car('Toyota', 'Corolla', 2015);

  print('Brand: ${myCar.brand}');
  print('Model: ${myCar.model}');
  print('Year: ${myCar.year}'); ;

  print("----------------after updated attributes----------------");  


  myCar.brand = 'Honda';
  myCar.model = 'Civic';
  myCar.year = 2020;

  print('Brand: ${myCar.brand}'); 
  print('Model: ${myCar.model}'); 
  print('Year: ${myCar.year}'); 
}