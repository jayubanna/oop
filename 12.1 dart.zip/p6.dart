class Movie {
  String title;
  String director;
  double rating;

  Movie({required this.title, required this.director, required this.rating});

  @override
  String toString() {
    return 'Movie: $title, Director: $director, Rating: $rating/10';
  }
}

void main()
{
  List<Movie> movies = [
  Movie(title: 'Dilwale Dulhania Le Jayenge', director: 'Aditya Chopra', rating: 8.8),
  Movie(title: 'Lagaan', director: 'Ashutosh Gowariker', rating: 8.1),
  Movie(title: 'Taare Zameen Par', director: 'Aamir Khan', rating: 8.1),
  Movie(title: '3 Idiots', director: 'Rajkumar Hirani', rating: 8.4),
  Movie(title: 'PK', director: 'Rajkumar Hirani', rating: 8.1),
  Movie(title: 'Dangal', director: 'Nitesh Tiwari', rating: 8.1),
  ];

  for (var movie in movies) {
    print(movie);
  }
}